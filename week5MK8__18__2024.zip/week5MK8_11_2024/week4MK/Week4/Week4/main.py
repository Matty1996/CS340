import AnimalShelter

def main():
    animal_shelter = AnimalShelter("aacuser", "SNHU1234")
    
    new_animal = {"name": "Pancake", "species": "Dog", "age": 5}
     
    
    # Create 
    create_result = animal_shelter.create(new_animal)
    if create_result.acknowledged:
        print("Successfully created")
    else:
        print("Could not create")
    
    # Read 
    search_query = {"name": "Pancake"}
    results = animal_shelter.read(search_query)
    if results:
        print("Animal Records found:")
        for result in results:
            print(result)
    else:
        print("No Animal Records found")
    
    # Update
    update_query = {"name": "Pancake"}
    new_data = {"age": 4}
    modified_count = animal_shelter.update(update_query, new_data)
    if modified_count > 0:
        print("Successfully updated")
    else: 
        print("Could not update")
    
    # Delete  
    delete_query = {"name": "Pancake"}
    deleted_count = animal_shelter.delete(delete_query)
    if deleted_count > 0:
       print("Successfully deleted")
    else: 
        print("Could not update")