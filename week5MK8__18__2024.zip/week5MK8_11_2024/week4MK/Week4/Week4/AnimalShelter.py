from pymongo import MongoClient

class AnimalShelter:

    def __init__(self, username, password, host='nv-desktop-services.apporto.com', port=32465, db='aac', col='animals'): 
       # USER = 'aacuser'
       # PASS = 'SNHU1234'
        #HOST = 'nv-desktop-services.apporto.com'
       # PORT = 32465  
       # DB = 'aac'
       # COL = 'animals'

        
        connection_string = f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?directConnection=true&appName=mongosh+1.8.0"

       
        self.client = MongoClient(connection_string)
        self.database = self.client[DB]  
        self.collection = self.database[COL]  
       

    def create(self, data):
        if data is not None:
           result = self.collection.insert_one(data)
           print('Successfully created')
           return result
         
        else:
            raise Exception("Could not create")
           

    def read(self, query):
        return list(self.collection.find(query))
        print('Animal Records found') 

    def update(self, query, new_data):
        if query and new_data:
            return self.collection.update_many(query, {'$set': new_data}).modified_count
            print('Successfully updated')
        else:
            raise Exception("Both query and new_data parameters are required")
            print('Could not update')
            
    def delete(self, query):
        if query:
            return self.collection.delete_many(query).deleted_count
            print('Successfully deleted')
        else:
            raise Exception("Query parameter is required")
            print('Could not delete')